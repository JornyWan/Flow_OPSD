# CODEX-0003 smoke retry record

Status: completed and validated. See `../../0004_CONSTRAINED_RETENTION_SMOKE_RESULT.md`.

This retry changes only the initialization order of the Min-SNR compatibility
validation. It otherwise inherits the method and acceptance criteria from 0002.

Inputs:

- audited base config SHA256: `f55f19c0351ed8bf56117fc925a8419b461828a87260ae2729c2cdd3880db36f`
- audited base trainer SHA256: `0f50637504eee01bfcfc1aaa306442d44fa77b00f5e1e284563650aee604d015`
- method overlay: `code/0002_constrained_retention.patch`
- correction overlay: `code/0003_fix_snr_init_order.patch`
- initializer: `models/DiffusionOPD/Student/lora`
- requested resources: 2 x H100 on `ai-gpu14`, preempt/low QoS
- epochs: 3; global samples/epoch: 72; online evaluation: disabled

Preflight and submission:

- both overlays apply sequentially to the audited source
- intermediate 0002 trainer hash matches the pinned expected hash
- corrected config/trainer compile
- CPU hinge/mask test passes
- resolved two-GPU config passes all invariants
- scheduler `--test-only` accepted the resource request
- command: `sbatch codex_research/slurm/0003_cr_smoke_retry.slurm`
- scheduler response: `Submitted batch job 1035891`
- output: `codex_research/runs/0003_cr_smoke_retry/slurm_1035891.out`
- correction patch SHA256: `bcdfbc306d29ec56f743cae932c964d72b9c9ad95ac914f6e4f3c75adbae4992`
- corrected trainer SHA256: `bedcbc8fbf4a6fa21705876b93db01aad0b551696630cda775505f88b53956a7`

Completion:

- SLURM state/exit: `COMPLETED`, `0:0`
- elapsed/node: `00:04:34`, `ai-gpu14`
- final global step: 3
- checkpoints: 1, 2, 3
- metrics export: `metrics.tsv`
- valid scope: optimization/control-flow smoke only; no performance claim
