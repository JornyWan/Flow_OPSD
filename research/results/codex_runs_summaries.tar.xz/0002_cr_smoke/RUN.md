# CODEX-0002 smoke run record

Status: invalid. SLURM job `1035889` failed before sampling or optimization.

Purpose: validate the control flow for one direct PickScore objective (slot 0)
plus external-teacher retention constraints for OCR and GenEval (slots 1 and 2).
This run is not a performance comparison.

Immutable inputs:

- base `config/opd.py` SHA256: `f55f19c0351ed8bf56117fc925a8419b461828a87260ae2729c2cdd3880db36f`
- base `scripts/train_sd3_opd.py` SHA256: `0f50637504eee01bfcfc1aaa306442d44fa77b00f5e1e284563650aee604d015`
- overlay: `codex_research/code/0002_constrained_retention.patch`
- initializer: `models/DiffusionOPD/Student/lora`
- requested resources: 2 x H100 on `ai-gpu14`, preempt/low QoS
- epochs: 3; global samples/epoch: 72; online evaluation: disabled

Pre-submit checks completed:

- overlay applies with `patch --dry-run -p1`
- patched config and trainer compile with `py_compile`
- configuration resolves to three named slots with routing `0 -> direct`,
  `[1, 2] -> retention`
- two-GPU scaling resolves to `nbpe=12`, `gas=12`, and 72 samples/epoch
- CPU-only hinge/mask test passes (to be rerun inside the job)

Submission:

- command: `sbatch codex_research/slurm/0002_cr_smoke.slurm`
- scheduler response: `Submitted batch job 1035889`
- output: `codex_research/runs/0002_cr_smoke/slurm_1035889.out`
- overlay SHA256: `65a05f8f8cbe2770340cbf598194aa66a2f5787a1752b0f3f8380507ad9a3374`
- SLURM script SHA256: `a6b1bed0685ae832931763b01c4aa7e695314a91c436e04967e3a5dd37ce136d`
- equation test SHA256: `2c682b6ef9c4097e9150ebe21f8a485fbef9a3eed118a8275c0d47e322a01714`

Acceptance conditions are defined in `0002_CONSTRAINED_RETENTION_EXPERIMENT.md`.
The SLURM output is the authoritative runtime manifest because it prints source
hashes, resolved hardware/configuration, launch command, invariants, and exit code.

Observed result:

- SLURM: `FAILED`, exit `1:0`, elapsed `00:00:33`
- passed: audited hashes, both overlays (dry-run/application), CPU mask test,
  resolved-config test, 2-GPU visibility, three teacher adapters and Student loading
- failed: `UnboundLocalError` because the new validation referenced `snr_weight`
  before the existing assignment
- optimizer updates: 0
- checkpoints: 0
- disposition: implementation failure only; no method conclusion
- correction: sequence 0003
